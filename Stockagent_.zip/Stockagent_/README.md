# 🤖 Stockagent — AI-Powered Stock Market Simulation

Stockagent is an educational multi-agent market simulation built with Python and Large Language Models (LLMs).

It creates autonomous simulated traders with different personalities. Each trader receives market information and decides whether to buy, sell, hold, or request a simulated loan. Orders are matched inside a virtual market and the results are saved for analysis.

> ⚠️ **Educational simulation only.** This project does not connect to a brokerage, execute real trades, or provide financial advice.

## ✨ Features

- 🤖 Gemini-powered autonomous trading agents
- 🎭 Conservative, Aggressive, Balanced and Growth-Oriented personalities
- 📈 Two simulated stocks: A and B
- 💰 Cash, holdings and simulated loans
- 🔄 Buy/sell order matching
- 💬 Simulated trader forum messages
- 📊 CSV transaction and portfolio records
- 📋 JSON simulation summary
- 🧪 Offline `demo` mode that needs no API key
- 🔐 API keys kept outside Git with `.env`

## 🧠 How It Works

1. Traders receive their starting cash, holdings and loan state.
2. Each day they decide whether to take a simulated loan.
3. During each trading session they submit a buy, sell or no-action decision.
4. Matching orders create simulated transactions.
5. Stock prices update from executed trades.
6. Traders publish short simulated forum observations.
7. The simulation saves market and portfolio results in `res/`.

## 🛠️ Technology

- Python 3.10+
- Google Gemini API
- OpenAI API support
- python-dotenv
- Colorama
- CSV / JSON
- Git & GitHub

## 📂 Project Structure

```text
Stockagent/
├── agent.py
├── main.py
├── secretary.py
├── stock.py
├── record.py
├── util.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── prompt/
│   ├── __init__.py
│   └── agent_prompt.py
├── log/
│   └── custom_logger.py
└── res/
    └── .gitkeep
```

## 🚀 Installation

### 1. Clone

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd Stockagent
```

### 2. Create a virtual environment

macOS / Linux:

```bash
python3 -m venv stockagent-env
source stockagent-env/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

## 🔑 Gemini API Setup

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Open `.env` and replace the placeholder with your own Gemini API key:

```text
GOOGLE_API_KEY=your_gemini_api_key_here
DEFAULT_MODEL=gemini-3.1-flash-lite
```

Never commit `.env` or paste an API key into GitHub.

## ▶️ Run Offline Demo

You can test the complete simulation without an API key:

```bash
python main.py --model demo --agents 6 --days 5 --sessions 2
```

The demo mode uses deterministic simulation logic for quick testing.

## 🤖 Run with Gemini

After configuring `.env`:

```bash
python main.py --model gemini-3.1-flash-lite --agents 6 --days 5 --sessions 2
```

For a larger experiment:

```bash
python main.py --model gemini-3.1-flash-lite --agents 20 --days 10 --sessions 3
```

The number of agents, days and sessions can be changed from the command line.

## 📊 Generated Results

After a run, the `res/` directory contains:

| File | Description |
|---|---|
| `summary.json` | Final prices and agent portfolio summary |
| `trades.csv` | Executed simulated trades |
| `stocks.csv` | Stock prices after each session |
| `agent_sessions.csv` | Agent state and actions |
| `agent_daily.csv` | Loan decisions and next-day estimates |

Logs are written to:

```text
log/simulation.log
```

Generated results and logs are ignored by Git so the repository stays clean.

## 🧪 Validation

The project validates AI responses before applying them to the simulation.

Loan responses must contain:

```json
{"loan":"no"}
```

or:

```json
{"loan":"yes","loan_type":0,"amount":1000}
```

Trading responses must contain:

```json
{"action_type":"buy","stock":"A","amount":10,"price":30.0}
```

or:

```json
{"action_type":"sell","stock":"B","amount":5,"price":18.0}
```

or:

```json
{"action_type":"no"}
```

Invalid responses are retried and safely converted to no-action when validation fails repeatedly.

## 🎯 Learning Outcomes

This project demonstrates:

- Artificial Intelligence
- Large Language Models
- Multi-Agent Systems
- Prompt Engineering
- Python Programming
- API Integration
- Market Simulation
- Data Processing
- Experiment Reproducibility
- Git/GitHub Project Management

## 🔮 Future Improvements

- Add more simulated companies
- Add richer market microstructure
- Compare LLM agents with rule-based baseline traders
- Add interactive charts/dashboard
- Add automated tests
- Add experiment comparison tools
- Add support for more model providers
- Improve structured model output handling

## 👩‍💻 Author

**Soleha Sayed**

Artificial Intelligence • Machine Learning • Data Science • Python • Web Development

## ⚠️ Disclaimer

This project is for educational and research purposes. It is a simulated environment and is not connected to real financial markets, brokerage accounts, or real-money trading.
